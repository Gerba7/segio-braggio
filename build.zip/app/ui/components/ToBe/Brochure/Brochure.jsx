import styles from './brochure.module.css';



const Brochure = () => {
  return (
    <div className={styles.container}>
        <h3 className={styles.title}>Descargar el brochure</h3>
        <p className={styles.paragraph}>
            Quisieras mas informacion antes de inscribirte? <br/>
            Descargue el folleto del curso para revisar los detalles del programa.
        </p>
        <a href={"../To-be-Evolucion-Personal-Brochure.pdf"} download="To be. Evolucion Personal.pdf" className={styles.button}  target='_blank'  aria-label="Brochure download">DESCARGAR AHORA</a>
    </div>
  )
}

export default Brochure
