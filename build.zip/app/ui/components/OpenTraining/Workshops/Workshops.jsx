import styles from './workshops.module.css';
import Link from 'next/link';
import Image from 'next/image';
import Decoration from '../../../../../public/images/decoration.png';
import Innovacion from '../../../../../public/images/innovacion.jpg';
import Customizacion from '../../../../../public/images/customizacion.jpg';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';





const Workshops = () => {
  return (
    <div className={styles.container}>
      <div className={styles.scrollOffset} id='servicios'></div>
        <div className={styles.top}>
            <p className={styles.paragraph}>Nuestros</p>
            <h3 className={styles.title}>SERVICIOS</h3>
        </div>
        <div className={styles.wrapper}>
            <div className={styles.valueContainer}>
                <Image src={Decoration} className={styles.decoration} alt='decoration' />
                <div className={styles.circleContainer}>
                    <Image src={Innovacion} className={styles.image} height={165} width={220} alt='Innovacion' />
                </div>
                <h5 className={styles.serviceTitle}>PROGRAMAS</h5>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        PNL Practitioner
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        PNL Master
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Coaching Ontológico
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Coaching organizacional
                    </p>
                </div>
                <Link href='/open-training/to-be' className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        To Be
                    </p>
                </Link>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Eneagrama
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Astrología Humanista
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        El poder de los Números
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Mente holográfica
                    </p>
                </div>
            </div>
            <div className={styles.valueContainer}>
                <Image src={Decoration} className={styles.decoration} alt='decoration' />
                <div className={styles.circleContainer}>
                    <Image src={Customizacion} className={styles.image} height={165} width={220} alt='Customizacion'/>
                </div>
                <h5 className={styles.serviceTitle}>TALLERES</h5>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Eneagrama corporativo
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        12 energías básicas
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Design Thinking
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Nuevos negocios
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Winner call
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Experiencia Disney
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Conversatoria
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Body Language
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Storytelling asertivo
                    </p>
                </div>
                <div className={styles.itemContainer}>
                    <ChevronRightIcon color='inherit' />
                    <p className={styles.description}>
                        Técnicas teatrales para Líderes
                    </p>
                </div>
            </div>
        </div>
        <Link href='#contacto' className={styles.button}>Contactanos</Link>
    </div>
  )
}

export default Workshops
